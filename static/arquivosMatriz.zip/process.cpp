#include <fstream>
#include <iostream>
#include <vector>
#include <unistd.h>
#include <sys/wait.h>
#include <chrono>
#include <string>

void multiplicaMatriz( // Parâmetros passados junto ao protótipo da matriz (sem struct)
    int inicio, int fim,
    std::vector<std::vector<int>> &A,
    std::vector<std::vector<int>> &B,
    std::vector<std::vector<int>> &C,
    int m1, int m2,
    std::string nomeArquivo
);

int main(int argc, char* argv[]) { // Recebendo parametros via linha de comando
    std::string arquivoA = argv[1];
    std::string arquivoB = argv[2];
    int numProcessos = std::atoi(argv[3]);

    std::ifstream inputA(arquivoA);
    std::ifstream inputB(arquivoB);

    int n1, m1, n2, m2;
    inputA >> n1 >> m1;
    inputB >> n2 >> m2;

    std::vector<std::vector<int>> matrizA(n1, std::vector<int>(m1));
    std::vector<std::vector<int>> matrizB(n2, std::vector<int>(m2));
    std::vector<std::vector<int>> matrizC(n1, std::vector<int>(m2));

    for(int i = 0; i < n1; i++)
        for(int j = 0; j < m1; j++) inputA >> matrizA[i][j];

    for(int i = 0; i < n2; i++)
        for(int j = 0; j < m2; j++) inputB >> matrizB[i][j];

    inputA.close();
    inputB.close();

    // Dividindo matirz para cada processo
    int divProcessos = n1 / numProcessos;

    // Loop for para teste AFK
    for(int it = 0; it < 10; it++) {
        auto totalStart = std::chrono::high_resolution_clock::now();

        // Loop for para criar os processos
        for (int p = 0; p < numProcessos; p++) {
            pid_t pid = fork();

            if (pid < 0) {
                perror("Falha no fork");
                return 1;
            }

            // Passa o código para os processos filhos
            if (pid == 0) {
                int inicio = p * divProcessos;
                int fim = (p == numProcessos - 1) ? n1 : (p + 1) * divProcessos;

                // Cria arquivo de saída para cada processo em cada iteração e multiplica a matriz
                std::string nomeArq = "resultadoProcess"+ std::to_string(m1) +"_P" + std::to_string(numProcessos) +
                                      "_it" + std::to_string(it+1) +
                                      "_p" + std::to_string(p) + ".txt";

                multiplicaMatriz(inicio, fim, matrizA, matrizB, matrizC, m1, m2, nomeArq);

                exit(0);
            }
        }

        // O pai espera os filhos terminarem
        for (int p = 0; p < numProcessos; p++) {
            wait(nullptr);
        }

        // Calcula o tempo e printa no terminal
        auto totalEnd = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> tempoTotal = totalEnd - totalStart;
        std::cout << tempoTotal.count() << " segundos na it " << it+1 << " com " << numProcessos << " processos" << std::endl;
    }

    return 0;
}

void multiplicaMatriz(
    int inicio, int fim,
    std::vector<std::vector<int>> &A,
    std::vector<std::vector<int>> &B,
    std::vector<std::vector<int>> &C,
    int m1, int m2,
    std::string nomeArquivo
) {
    std::ofstream outputR(nomeArquivo); // criando o arquivo
    //inicia timer
    auto start = std::chrono::high_resolution_clock::now();

    // calculo de c[i][j] como de costume
    for (int i = inicio; i < fim; i++) {
        for (int j = 0; j < m2; j++) {
            C[i][j] = 0;
            for (int k = 0; k < m1; k++) {
                C[i][j] += A[i][k] * B[k][j];
            }
            outputR << "c" << i << j << " " << C[i][j] << std::endl; //armazenando no arquivo.
        }
    }
    // Calcula o tempo final da operação
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> tempo = end - start;

    // fehca o arquivo
    outputR << tempo.count() << std::endl;
    outputR.close();
}
