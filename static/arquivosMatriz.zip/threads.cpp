#include <fstream>
#include <iostream>
#include <vector>
#include <pthread.h>
#include <string>
#include <chrono>

// Criando struct para passar como parâmetro da função de multiplicação
struct parametrosThread {
    int inicio, fim;
    std::vector<std::vector<int>> *matrizA;
    std::vector<std::vector<int>> *matrizB;
    std::vector<std::vector<int>> *matrizC;
    int m1, m2;
    std::string nomeArquivo;
};

void* multiplicaMatriz(void* arg); // A multiplicação da matriz agora é uma função

int main(int argc, char* argv[]) { // Recebendo prâmetros na linha de comando

    std::string arquivoA = argv[1];
    std::string arquivoB = argv[2];
    int numThreads = std::atoi(argv[3]);

    std::ifstream inputA(arquivoA);
    std::ifstream inputB(arquivoB);

    // Extraindo linhas e colunas do arquivo de entrada
    int n1, m1, n2, m2;
    inputA >> n1 >> m1;
    inputB >> n2 >> m2;

    //Criando matrizes
    std::vector<std::vector<int>> matrizA(n1, std::vector<int>(m1));
    std::vector<std::vector<int>> matrizB(n2, std::vector<int>(m2));
    std::vector<std::vector<int>> matrizC(n1, std::vector<int>(m2));

    // Extraindo dados dos arquivos
    for(int i = 0; i < n1; i++)
        for(int j = 0; j < m1; j++) inputA >> matrizA[i][j];

    for(int i = 0; i < n2; i++)
        for(int j = 0; j < m2; j++) inputB >> matrizB[i][j];

    inputA.close();
    inputB.close();

    // Dividindo matrizes pelo numero de threads a ser executada
    int divThreads = n1 / numThreads;

    for(int it = 0; it < 10; it++) { // Loop for pra teste afk
        auto totalStart = std::chrono::high_resolution_clock::now(); //incicia medição do tempo

        // Vetor de threads e parâmetros de therads
        std::vector<pthread_t> threads(numThreads);
        std::vector<parametrosThread> args(numThreads);

        // Cria as threads com os parametros necessários
        for(int t = 0; t < numThreads; t++) {
            args[t].inicio = t * divThreads;
            args[t].fim = (t == numThreads - 1) ? n1 : (t + 1) * divThreads; // fim da parte (ultima thread pega o resto)
            args[t].matrizA = &matrizA; // Passando as matrizes por ref
            args[t].matrizB = &matrizB;
            args[t].matrizC = &matrizC;
            args[t].m1 = m1;
            args[t].m2 = m2;
            args[t].nomeArquivo = "resultadoThreads"+ std::to_string(m1) +"_T" // Defininfo nome dos arquivos de cada thread em casa it
            + std::to_string(numThreads)
            + "_it" + std::to_string(it+1)
            + "_t" + std::to_string(t) + ".txt";

            // Cria efetivamente as threads
            pthread_create(&threads[t], nullptr, multiplicaMatriz, (void*)&args[t]);
        }

        // esperando fim das threads
        for(int t = 0; t < numThreads; t++) {
            pthread_join(threads[t], nullptr);
        }

        //Calcula o tempo total (o que vai ser impreso no terminal)
        auto totalEnd = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> tempoTotal = totalEnd - totalStart;
        std::cout << tempoTotal.count() << " segundos na it " << it+1 << " com " << numThreads << " threads" << std::endl;
    }

    return 0;
}

void* multiplicaMatriz(void* arg) {
    // Recebe os parâmetros e aloca as matrizes
    parametrosThread* p = (parametrosThread*)arg;
    std::vector<std::vector<int>> &A = *(p->matrizA);
    std::vector<std::vector<int>> &B = *(p->matrizB);
    std::vector<std::vector<int>> &C = *(p->matrizC);

    // Cria o arquivo de saída
    std::ofstream outputR(p->nomeArquivo);
    outputR << (p->fim - p->inicio) << " " << p->m2 << std::endl;

    // Inciai a medição do tempo da thread
    auto start = std::chrono::high_resolution_clock::now();

    //  Multiplicação como de costume
    for (int i = p->inicio; i < p->fim; i++) {
        for (int j = 0; j < p->m2; j++) {
            C[i][j] = 0;
            for (int k = 0; k < p->m1; k++) {
                C[i][j] += A[i][k] * B[k][j];
            }
            outputR << "c" << i << j << " " << C[i][j] << std::endl; // Armazena os valores no arquivo individual de cada thread
        }
    }

    // Calcula o tempo da thread
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> tempo = end - start;

    // Armazena o tempo no final do arquivo e encerra a thread
    outputR << tempo.count() << std::endl;
    outputR.close();
    pthread_exit(nullptr);
}
