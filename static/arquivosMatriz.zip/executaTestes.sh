#!/bin/bash

# 1. Compilação com otimização máxima (-O3)
echo "Compilando os códigos..."
g++ -O3 programaAuziliar.cpp -o auxiliar
g++ -O3 sequencial.cpp -o sequencial
g++ -O3 threads.cpp -lpthread -o threads
g++ -O3 process.cpp -o process

# Listas de configurações conforme o PDF do professor
TAMANHOS=(100 200 400 800 1600 3200 4000)
THREADS_PROC=(2 4 8 16)

echo "Criando matrizes para teste"
echo "-----------------------------------"

echo Matriz 100
./auxiliar 100 100 100 100
echo Matriz 200
./auxiliar 200 200 200 200
echo Matriz 400
./auxiliar 400 400 400 400
echo Matriz 800
./auxiliar 800 800 800 800
echo Matriz 1600
./auxiliar 1600 1600 1600 1600
echo Matriz 3200
./auxiliar 3200 3200 3200 3200
echo Matriz 4000
./auxiliar 4000 4000 4000 4000
echo "Matrizes criadas com sucesso"
echo "-----------------------------------"
echo "Iniciando bateria de testes..."
echo "-----------------------------------"

for DIM in "${TAMANHOS[@]}"
do
    ARQ_A="matrizA${DIM}.txt"
    ARQ_B="matrizB${DIM}.txt"

    # Verifica se os arquivos de matriz existem antes de rodar
    if [[ -f "$ARQ_A" && -f "$ARQ_B" ]]; then
        
        echo ">>> Testando matriz ${DIM}x${DIM}"

        # --- Execução Sequencial ---
        echo "Executando Sequencial..."
        ./sequencial "$ARQ_A" "$ARQ_B"

        # --- Execução Paralela (Threads e Processos) ---
        for TP in "${THREADS_PROC[@]}"
        do
            echo "Executando Threads com T=$TP..."
            ./threads "$ARQ_A" "$ARQ_B" "$TP"

            echo "Executando Processos com P=$TP..."
            ./process "$ARQ_A" "$ARQ_B" "$TP"
        done
        
        echo "-----------------------------------"
    else
        echo "Aviso: Arquivos para ${DIM}x${DIM} não encontrados. Pulando..."
    fi
done

echo "Todos os testes foram concluídos!"
