#include <iostream>
#include <ctime>
#include <fstream>
#include <vector>

int main(int argc, char** argv) {   // Recebe parâmetros via linha de comando
    int n1, m1, n2, m2;
    
    n1 = std::atoi(argv[1]);
    m1 = std::atoi(argv[2]);
    n2 = std::atoi(argv[3]);
    m2 = std::atoi(argv[4]);

    // Cria arquivos de saída no formato matrizA[ORDEM].txt
    std::string nomeArquivoA = "matrizA" + std::to_string(n1) + ".txt";
    std::string nomeArquivoB = "matrizB" + std::to_string(n1) + ".txt";

    std::ofstream saidaMA(nomeArquivoA);
    std::ofstream saidaMB(nomeArquivoB);

    // Insere dimensões na primeira linha do arquivo da saída
    saidaMA << n1 << " " << m1 << std::endl;
    saidaMB << n2 << " " << m1 << std::endl;

    // Esse vetor na verdade é desnecessário
    std::vector<std::vector<int>> matrizA(n1, std::vector<int>(m1));
    std::vector<std::vector<int>> matrizB(n1, std::vector<int>(m1));

    std::srand(std::time(nullptr));

    // Preenchendo matriz com valores aleatórios
    for(int i = 0; i < n1; i++){
        for(int j = 0; j < m1; j++){
            matrizA[i][j]= std::rand() % 1000;
        }
    }
    
    for(int i = 0; i < n2; i++){
        for(int j = 0; j < m2; j++){
            matrizB[i][j] = std::rand() % 1000;
        }
    }

    // Armazena os elementos de matriz no arquivo de saída
    for(int i = 0; i < n1; i++){
        for(int j = 0; j < m1; j++){
            saidaMA << matrizA[i][j] << " ";
        }
        saidaMA << std::endl;
    }

    for(int i = 0; i < n1; i++){
        for(int j = 0; j < m1; j++){
            saidaMB << matrizB[i][j] << " ";
        }
        saidaMB << std::endl;
    }

    saidaMA.close();
    saidaMB.close();

    return 0;
}