#include <fstream>
#include <iostream>
#include <ctime>
#include <vector>
#include <string>

int main(int argc, char **argv) { // Recebendo arquivos via linha de comando

    std::ifstream inputA(argv[1]);
    std::ifstream inputB(argv[2]);

    // Extraindo dimensões dos arquivos
    int n1, m1, n2, m2;
    inputA >> n1 >> m1;
    inputB >> n2 >> m2;

    // Criando matrizes para armazenas os valores
    std::vector<std::vector<int>> matrizA(n1, std::vector<int>(m1));
    std::vector<std::vector<int>> matrizB(n2, std::vector<int>(m2));
    std::vector<std::vector<int>> matrizC(n1, std::vector<int>(m2));

    // Extraindo valores dos arquivos
    for(int i = 0; i < n1; i++){
        for(int j = 0; j < m1; j++){
            inputA >> matrizA[i][j];
        }
    }

    for(int i = 0; i < n2; i++){
        for(int j = 0; j < m2; j++){
            inputB >> matrizB[i][j];
        }
    }

    inputA.close();
    inputB.close();
    
    double somaTempos = 0;

    for(int t = 0; t < 10; t++){ //Laço for para facilitar os 10 testes (teste afk)

        // Criando arquivo no formato resultadoSequencial[ORDEM]_it[i].txt
        std::string arquivoResultado = "resultadoSequencial" + std::to_string(n1) + "_it" + std::to_string(t + 1) + ".txt";
        std::ofstream outputR(arquivoResultado);

        outputR << n1 << " " << m2 << std::endl; 

        // Inicia contagem de tempo
        clock_t start = clock();

        for(int i = 0; i < n1; i++){
            for(int j = 0; j < m2; j++){
                matrizC[i][j] = 0;
                for(int k = 0; k < m1; k++) {
                    matrizC[i][j] += matrizA[i][k] * matrizB[k][j];
                }
                outputR << "c" << i << j << " " << matrizC[i][j] << std::endl; // armazenando os valores no arquivo de saída
            }
        }

        clock_t end = clock();
        double tempoIt = ((double)(end - start)) / CLOCKS_PER_SEC;

        outputR << tempoIt << std::endl; // Armazenando o tempo total da iteração no arquivo

        std::cout << tempoIt << " segundos na it:" << t+1 << std::endl;
        somaTempos += tempoIt; //Apenas para vizualização

        outputR.close();
    }
    
    std::cout << "Tempo Médio Sequencial: " << somaTempos/10 << " segundos" << std::endl; //imprime no erminal, apenas para vizualização

    return 0;
}
