import os
import re
from collections import defaultdict

PASTA = "."

def ler_tempo(caminho):
    with open(caminho, "r") as f:
        linhas = [linha.strip() for linha in f.readlines() if linha.strip()]
        return float(linhas[-1])

def processar():
    sequencial = defaultdict(list)

    # Agora com separação por quantidade
    threads = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
    processos = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))

    for arquivo in os.listdir(PASTA):
        caminho = os.path.join(PASTA, arquivo)

        # ---------------- SEQUENCIAL ----------------
        m = re.match(r"resultadoSequencial(\d+)_it(\d+)\.txt", arquivo)
        if m:
            tamanho = int(m.group(1))
            tempo = ler_tempo(caminho)
            sequencial[tamanho].append(tempo)
            continue

        # ---------------- THREADS ----------------
        m = re.match(r"resultadoThreads(\d+)_T(\d+)_it(\d+)_t(\d+)\.txt", arquivo)
        if m:
            tamanho = int(m.group(1))
            qtd_threads = int(m.group(2))
            iteracao = int(m.group(3))

            tempo = ler_tempo(caminho)
            threads[tamanho][qtd_threads][iteracao].append(tempo)
            continue

        # ---------------- PROCESSOS ----------------
        m = re.match(r"resultadoProcess(\d+)_P(\d+)_it(\d+)_p(\d+)\.txt", arquivo)
        if m:
            tamanho = int(m.group(1))
            qtd_processos = int(m.group(2))
            iteracao = int(m.group(3))

            tempo = ler_tempo(caminho)
            processos[tamanho][qtd_processos][iteracao].append(tempo)
            continue

    resultado = {}

    for tamanho in sequencial.keys():
        resultado[tamanho] = {}

        # -------- Sequencial --------
        media_seq = sum(sequencial[tamanho]) / len(sequencial[tamanho])
        resultado[tamanho]["sequencial"] = media_seq

        # -------- Threads --------
        resultado[tamanho]["threads"] = {}
        for qtd in threads[tamanho]:
            maiores = [
                max(threads[tamanho][qtd][it])
                for it in threads[tamanho][qtd]
            ]
            media = sum(maiores) / len(maiores)
            resultado[tamanho]["threads"][qtd] = media

        # -------- Processos --------
        resultado[tamanho]["processos"] = {}
        for qtd in processos[tamanho]:
            maiores = [
                max(processos[tamanho][qtd][it])
                for it in processos[tamanho][qtd]
            ]
            media = sum(maiores) / len(maiores)
            resultado[tamanho]["processos"][qtd] = media

    return resultado


def salvar(resultado):
    with open("resumo.txt", "w") as f:
        for tamanho in sorted(resultado.keys()):
            f.write(f"Matriz {tamanho}x{tamanho}:\n")

            f.write(f"Tempo médio sequencial: {resultado[tamanho]['sequencial']:.6f}\n")

            # Threads
            f.write("Threads:\n")
            for qtd in sorted(resultado[tamanho]["threads"].keys()):
                media = resultado[tamanho]["threads"][qtd]
                f.write(f"  {qtd} threads: {media:.6f}\n")

            # Processos
            f.write("Processos:\n")
            for qtd in sorted(resultado[tamanho]["processos"].keys()):
                media = resultado[tamanho]["processos"][qtd]
                f.write(f"  {qtd} processos: {media:.6f}\n")

            f.write("\n")


if __name__ == "__main__":
    resultado = processar()
    salvar(resultado)
    print("Resumo gerado em resumo.txt")
